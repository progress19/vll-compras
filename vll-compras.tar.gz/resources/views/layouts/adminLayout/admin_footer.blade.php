<!-- footer content -->
{{-- 
<footer>
  <div class="pull-right">
    Compras Vll - BackOffice by <a href="http://mauriciolavilla.ml" target="_new">MauricioLavilla</a>
  </div>
  <div class="clearfix"></div>
</footer>
--}}
<!-- /footer content -->