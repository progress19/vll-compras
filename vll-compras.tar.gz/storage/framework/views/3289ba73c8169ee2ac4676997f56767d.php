<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js-script'); ?>

	<?php if(session('flash_message')): ?>
	  <script>toast('<?php echo session('flash_message'); ?>');</script>
	<?php endif; ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.adminLayout.admin_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/vll-compras/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>