<?php
  use App\Fun;
?>


<?php $__env->startSection('content'); ?>

      <div class="col-md-12 col-sm-12 ">
        <div class="x_panel animate__animated animate__fadeIn">

          <div class="x_title">
            <h2><i class="fa fa-users"></i> Usuarios /<small>Lista</small></h2>

            <div class="clearfix"></div>
          </div>

          <div class="x_content">

            <div class="row">
              <div class="col-sm-12">
                <div class="card-box">

                  <table class="hover table table-striped table-bordered dt-responsive nowrap" id="table" style="width:100%">
                    <thead>
                      <tr>
                        <th>Nombre</th>
                        <th>Email</th>
                        <th>Rol</th>
                        <th>Estado</th>
                        <th></th>
                      </tr>
                    </thead>
                  </table>

                </div>
              </div>
            </div>

          </div>

        </div>
      </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js-script'); ?>
  <?php if(session('flash_message')): ?>
    <script>toast('<?php echo session('flash_message'); ?>');</script>
  <?php endif; ?>
  
<script>

$(function() {
    $('#table').DataTable({
        processing: true,
        //serverSide: true,
        ajax: '<?php echo route('dataUsuarios'); ?>',

        columns: [

            {data: 'nombre', name: 'nombre'},
            {data: 'email'},
            {data: 'rol'},
            {data: 'estado', orderable: false, searchable: false, className: 'dt-body-center'},
            {data: 'acciones',title: '',orderable: false, searchable: false, className: 'dt-body-center'},
        
        ],

        language: {
            "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
         },
    });
});

$(document).ready(function() {
    $('#table tbody').on( 'click', '.delReg', function () {
    if (confirm('Está seguro de eliminar el registro ?')) {
        return true;
    }
    return false;
    });
});

</script>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.adminLayout.admin_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/vll-compras/resources/views/admin/usuarios/view_usuarios.blade.php ENDPATH**/ ?>