<!-- footer content -->

<!-- /footer content --><?php /**PATH /opt/lampp/htdocs/vll-compras/resources/views/layouts/adminLayout/admin_footer.blade.php ENDPATH**/ ?>