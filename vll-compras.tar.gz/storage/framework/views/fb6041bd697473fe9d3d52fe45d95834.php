<?php $__env->startSection('content'); ?>

              <div class="col-md-9 col-sm-9 col-xs-9">
                <div class="x_panel animate__animated animate__fadeIn">
                  <div class="x_title">
                    <h2><i class="fa fa-users"></i> Usuarios<small>/ Nuevo</small></h2>
                    <ul class="nav navbar-right panel_toolbox"></ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                   
  <?php echo e(Form::open([
  	'id' => 'add_usuario',
  	'name' => 'add_usuario',
  	'url' => '/admin/agregar-usuario',
  	'role' => 'form',
  	'method' => 'post',
    'files' => true])); ?>


              <div class="col-md-4">
                <div class="form-group">
                  <?php echo Form::label('name', 'Nombre'); ?>

                  <?php echo Form::text('name', null, ['id' => 'name', 'class' => 'form-control']); ?>

                </div>
              </div>

              <div class="clearfix"></div>

              <div class="col-md-4">
                <div class="form-group">
                  <?php echo Form::label('email', 'Email'); ?>

                  <?php echo Form::text('email', null, ['id' => 'email', 'class' => 'form-control']); ?>

                </div>
              </div>

              <div class="col-md-4">
                <div class="form-group">
                  <?php echo Form::label('password', 'Contraseña'); ?>

                  <?php echo Form::password('password',['id' => 'password', 'class' => 'form-control', 'placeholder' => '']); ?>

                </div>
              </div>

               <div class="clearfix"></div>

              <div class="col-md-3">
                <div class="form-group">
                  <?php echo Form::label('rol', 'Rol'); ?>

                  <?php echo Form::select('rol', array('1' => 'Administrador', '0' => 'Operador'), null, ['id' => 'rol', 'class' => 'form-control']); ?>

                </div>
              </div> 

                <div class="col-md-3">
                  <div class="form-group">
                    <?php echo Form::label('estado', 'Estado'); ?>

                    <?php echo Form::select('estado', array('1' => 'Activado', '0' => 'Desactivado'), null, ['id' => 'estado', 'class' => 'form-control']); ?>

                  </div>
                </div>   

                <div class="col-md-12"><div class="ln_solid"></div>
                <button id="send" type="submit" class="btn btn-success pull-right"><i class="fa fa-floppy-o" aria-hidden="true"></i>
                   Guardar</button>
              </div>

    <?php echo Form::close(); ?>


                  </div>
                </div>
              </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js-script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout.admin_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/vll-compras/resources/views/admin/usuarios/add_usuario.blade.php ENDPATH**/ ?>