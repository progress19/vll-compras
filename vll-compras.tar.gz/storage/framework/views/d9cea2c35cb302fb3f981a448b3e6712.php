<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta name="csrf_token" content="<?php echo e(csrf_token()); ?>" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.png')); ?>" type="image/x-icon">

    <title>Compras VLL | BackOffice </title>

    <!-- Bootstrap -->
    <link href="<?php echo e(asset('vendors/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?php echo e(asset('vendors/nprogress/nprogress.css')); ?>" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo e(asset('vendors/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <!-- bootstrap-datepicker -->
    <link href="<?php echo e(asset('vendors/bootstrap-datepicker/css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet">
    <!-- Toast -->
    <link href="<?php echo e(asset('vendors/toast/jquery.toast.css')); ?>" rel="stylesheet">
    <!-- Datatables -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.12.1/r-2.3.0/datatables.min.css"/>
    <!-- Select2 -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
    
    <!-- Switchery -->
    
    
    <!-- Custom Theme Style -->
    <link href="<?php echo e(asset('css/back_css/custom.css')); ?>" rel="stylesheet">
    <!-- Custom Theme Style -->
    <link href="<?php echo e(asset('css/back_css/hover-min.css')); ?>" rel="stylesheet">
    <!-- Multi-Select -->
    
    <!-- Animate -->
    <link href="<?php echo e(asset('vendors/animate.css/animate.min.css')); ?>" rel="stylesheet">

  </head>

  <body class="nav-md">

    <div class="container body">
      <div class="main_container">
        
        <?php echo $__env->make('layouts.adminLayout.admin_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.adminLayout.admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       
        <div class="right_col" role="main">

          <div class="back_logo"></div>    

         <div class="container">
            <div class="clearfix"></div>
              <div class="row">
                <?php echo $__env->yieldContent('content'); ?>
              </div>
          </div>
        </div>

        <?php echo $__env->make('layouts.adminLayout.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      </div>
    </div>

    <a href="#0" class="cd-top js-cd-top">Top</a>

    <!-- jQuery -->
    <script src="<?php echo e(asset('vendors/jquery/dist/jquery.min.js')); ?>"></script>
    <!-- Bootstrap -->
    <script src="<?php echo e(asset('vendors/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- FastClick -->
    
    <!-- NProgress -->
    <script src="<?php echo e(asset('vendors/nprogress/nprogress.js')); ?>"></script>
    <!-- gauge.js -->
    
    <!-- bootstrap-progressbar -->
    
    <!-- iCheck -->
    
    
    <!-- DateJS -->
    

    <!-- bootstrap-daterangepicker -->
    
    

    <!-- bootstrap-wysiwyg -->
    
    
    
        
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.12.1/r-2.3.0/datatables.min.js"></script>

<!-- https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js -->

    

    <!-- bootstrap-datepicker -->
    <script src="<?php echo e(asset('vendors/bootstrap-datepicker/js/bootstrap-datepicker.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>    
    <script src="<?php echo e(asset('js/back_js/forms.js')); ?>"></script>
    
    <script src="<?php echo e(asset('vendors/toast/jquery.toast.js')); ?>"></script>

    <!-- Select2 -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>

    <!-- Switchery -->
    

    <!-- Custom Theme Scripts -->
    <script src="<?php echo e(asset('js/back_js/custom.js')); ?>"></script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.2.2/jquery.form.min.js" integrity="sha256-2Pjr1OlpZMY6qesJM68t2v39t+lMLvxwpa8QlRjJroA=" crossorigin="anonymous"></script>

    <script src="//cdn.ckeditor.com/4.14.1/basic/ckeditor.js"></script>
	
  </body>

<?php echo $__env->yieldContent('page-js-script'); ?>

</html>
<?php /**PATH /opt/lampp/htdocs/vll-compras/resources/views/layouts/adminLayout/admin_design.blade.php ENDPATH**/ ?>